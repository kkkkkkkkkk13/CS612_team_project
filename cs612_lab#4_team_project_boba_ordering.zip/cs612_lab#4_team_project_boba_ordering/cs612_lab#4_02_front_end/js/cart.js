
// JavaScript for handling cart functionality
console.log('Cart script loaded');
