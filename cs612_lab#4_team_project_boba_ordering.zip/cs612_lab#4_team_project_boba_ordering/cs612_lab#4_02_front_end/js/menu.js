
// JavaScript for handling menu interactions
console.log('Menu script loaded');
