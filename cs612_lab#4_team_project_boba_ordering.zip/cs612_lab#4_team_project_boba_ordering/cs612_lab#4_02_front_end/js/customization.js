
// JavaScript for handling drink customization
console.log('Customization script loaded');
